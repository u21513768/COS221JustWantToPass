How to run the PHP scripts:

1.Ensure that you have XAMPP installed. 
2.Insert the 'Task5' folder directly into the 'htdocs' directory of XAMPP.
3.Open task5/login/connection.php with a text editor and ensure the port for the
  $dbHost variable is set correctly according to the port your MariaDB database is running.
  Set the $dbPass variable to your password used to access the database.
4.Save and close the connection.php file.
5.Boot up the XAMPP Control Panel and ensure Apache and MySQL is running.
5.In your browser, type in "http://localhost/task5/login/index.php".
6.From there you may sign in or login and progress to the rest of the GUI.